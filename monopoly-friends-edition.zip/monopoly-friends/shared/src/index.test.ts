import {describe,it,expect} from 'vitest';
import {BOARD,nextPosition,rollDice} from './index.js';
describe('board rules',()=>{it('contains 40 spaces in order',()=>{expect(BOARD).toHaveLength(40);expect(BOARD[0].name).toBe('GO');expect(BOARD[39].name).toBe('Boardwalk');});it('wraps movement and detects passing GO',()=>{expect(nextPosition(38,4)).toEqual({position:2,passedGo:true});expect(nextPosition(3,4)).toEqual({position:7,passedGo:false});});it('rolls two dice in range',()=>{const d=rollDice(()=>0.5);expect(d).toEqual([4,4]);});});
