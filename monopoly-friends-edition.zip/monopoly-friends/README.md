# Monopoly — Friends Edition (starter implementation)

A TypeScript monorepo for a real-time, browser-based Monopoly-inspired game. It reconstructs a 40-space board from structured data; it does not use the uploaded reference image as the playable board.

## Quick start

Requirements: Node.js 20+ and npm.

```bash
npm install
cp .env.example .env
npm run dev
```

Open `http://localhost:5173`. The API and Socket.IO server runs on `http://localhost:4000`. Open a second browser/incognito window to test multiplayer room joining. Set `VITE_SERVER_URL` in `client/.env.local` if the server runs elsewhere.

## Workspace

- `client/`: React, TypeScript, Vite, Tailwind dependency, Framer Motion, Lucide, Socket.IO client.
- `server/`: Express health endpoint and Socket.IO authoritative in-memory room/game engine with Zod validation.
- `shared/`: typed 40-space board data, shared game types, basic rules and unit tests.

## Implemented in this starter

- Responsive landing page, room creation/joining, token selection, waiting room and host start control.
- Six token choices, 2–6 player rooms, unpredictable short room IDs, duplicate-token prevention, and live room updates.
- Structured 40-space board with color groups, owner indicators, token markers and property detail panel.
- Server-generated dice, movement, passing GO salary, unowned property purchase/decline, rent calculation for property/railroads/utilities, taxes, basic card events, jail entry, turn changes and bankruptcy flagging.
- Socket.IO table chat and activity log.
- Basic shared logic tests and environment template.

## Important scope and limitations

This is **not yet a complete production-ready Monopoly implementation**. Do not deploy it for public or competitive play without completing the items below. The source intentionally does not claim these unfinished features are working:

- PostgreSQL/Prisma persistence, migrations, user profiles, secure authentication, session management and stored game history are not implemented; room state is in-memory and is lost on restart.
- Reconnection recovery and host migration are not implemented.
- Auctions, trades, house/hotel construction and sales, mortgages, rent group bonuses, complete jail choices/doubles rules, Get Out of Jail Free cards, spectators, turn timers, ready-state checks, configurable room rules and full classic rules are not implemented.
- Game phases are a simplified subset; production hardening should use a formally validated transition table and atomic persistence/locking per room.
- Card decks are a small original sample rather than a balanced complete deck.
- No automated Playwright browser tests or full socket integration suite are included yet.
- The current server uses Socket.IO connection IDs as player IDs; durable identity and authenticated room membership must replace this before production.

## Tests and build

```bash
npm test
npm run build
```

Run these after installing dependencies. This environment did not install dependencies or execute browser tests, so no build/test pass is claimed here.

## Security checklist before deployment

- Add rate limiting and origin allowlists, authenticated room membership, reconnect tokens, server-side authorization and message schemas for every socket event.
- Persist game state with transactions/locking and add idempotency keys for financial actions.
- Replace `Math.random()` for room codes and game RNG with a cryptographically secure generator where appropriate.
- Add abuse reporting, chat moderation, privacy/terms pages, accessibility review and load testing.
- Configure HTTPS, secure cookies, secret rotation, database backups and observability.

## Configuration

Copy `.env.example` to `.env` and replace all sample secrets. The current in-memory starter does not consume `DATABASE_URL` or `SESSION_SECRET` yet.
