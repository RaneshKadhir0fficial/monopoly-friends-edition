export default {content:['./index.html','./src/**/*.{js,ts,jsx,tsx}'],theme:{extend:{colors:{forest:'#123B32',ivory:'#F5F0E5',gold:'#D7B56D'}}},plugins:[]};
